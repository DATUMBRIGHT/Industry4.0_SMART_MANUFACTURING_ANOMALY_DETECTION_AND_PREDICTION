import kagglehub

# Download latest version
path = kagglehub.dataset_download("ziya07/smart-manufacturing-iot-cloud-cloud-monitoring-dataset")

print("Path to dataset files:", path)


